import React, { useEffect } from 'react'
import Layout from '../common/Layout'
import { Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { redirectToProf } from '../redux/AuthSlice'
import { getServiceBooking } from '../redux/serviceBookingSlice'

const ProfileDashboard = () => {
    const dispatch=useDispatch()
    const { res:booking_details } = useSelector((state) => state?.serviceBooking);
    useEffect(()=>{
      dispatch(redirectToProf(null))
    },[])
    const name=localStorage.getItem("name")
    const email=localStorage.getItem('email')
    const DP=localStorage.getItem("image")
    const phone=localStorage.getItem("phone")
    const id = localStorage.getItem("id")

    console.log("Bookings", booking_details);
  
    useEffect(() => {
      dispatch(getServiceBooking(id));
    }, [id]);
  return (
   <>
   <Layout>
    {/* Dashboard Header */}
    <div className="container-fluid page-header mb-5">
        <div className="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style={{minHeight: '400px'}}>
            <h4 className="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase font-weight-bold">Welcome {name}</h4>
            {/* <div className="d-inline-flex">
                <p className="m-0 text-white"><Link className="text-white" to="/Login">Login</Link></p>
                <p className="m-0 text-white px-2">/</p>
                <p className="m-0 text-white">Registration</p>
            </div> */}
        </div>
    </div>
    {/* Header end */}

    {/* Profile Body */}
    <div className="container gym-class mb-5 mt-5">
        <div className="row px-3">
            <div className="col-md-5 p-0 m-auto">
                <div className="gym-class-box d-flex flex-column align-items-center justify-content-center bg-primary text-right text-white py-5 px-5" style={{borderRadius:'25px 0px 0px 25px'}}>
                    <i className="flaticon-six-pack"></i>
                    <div style={{marginBottom:'20px'}}><img src='https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png' alt='' className="rounded-circle" height={'150px'}/></div>
                    <h4  className="display-5 mb-2 text-white font-weight-bold">Name:<span style={{color:'yellow'}}>{name}</span></h4>
                    <h5  className="display-5 mb-2 text-white font-weight-bold">Email Id:<span style={{color:'yellow'}}>{email}</span></h5>
                    <h5  className="display-5 mb-2 text-white font-weight-bold">Phone no:<span style={{color:'yellow'}}>{phone}</span></h5>
                    {/* <h3 className="display-4 mb-3 text-white font-weight-bold">Body Building</h3>
                    <p>
                        Lorem justo tempor sit aliquyam invidunt, amet vero ea dolor ipsum ut diam sit dolores, dolor
                        sit eos sea sanctus erat lorem nonumy sanctus takimata. Kasd amet sit sadipscing at..
                    </p> */}
                    {/* <Link to="" className="btn btn-lg btn-outline-light mt-4 px-4">Edit Profile</Link> */}
            {/* <div className="d-flex justify-content-start mt-4">
                    <a className="btn btn-outline-light rounded-circle text-center mr-2 px-0" style={{width: '40px',height: '40px'}} href="#"><i class="fab fa-twitter"></i></a>
                    <a className="btn btn-outline-light rounded-circle text-center mr-2 px-0" style={{width: '40px',height: '40px'}} href="#"><i class="fab fa-facebook-f"></i></a>
                    <a className="btn btn-outline-light rounded-circle text-center mr-2 px-0" style={{width: '40px',height: '40px'}} href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a className="btn btn-outline-light rounded-circle text-center mr-2 px-0" style={{width: '40px',height: '40px'}} href="#"><i class="fab fa-instagram"></i></a>
                </div> */}
                </div>
            </div>
            <div className="col-md-7 p-0">
                <div className="gym-class-box d-flex flex-column align-items-start justify-content-center bg-secondary text-left text-white py-5 px-5 ">
                    <i className="flaticon-bodybuilding"></i>
                    <h1 className="display-5 mb-1 text-white ">Your Booking Status</h1>
                    <hr style={{ borderTop: '1px solid white' }} />
                    {/* <div style={{display:'flex'}}>
                   <h4 className='text-white'>Training Name</h4>
                   <h4 className='text-white ml-5'>Booking Status</h4>
                   </div> */}
                     {
                        booking_details?.data?.result?.map((item, index) => {
                          return (
                            <>
                              <div className="row pt-1">
                                <div className="col-6 mb-3">
                                  <h6 className='text-white'>Training Name</h6>
                                  <p className="text-white"><b>{item?.serviceId?.service_name}</b></p>
                                </div>
                                <div className="col-6 mb-3">
                                  <h6 className='text-white'>Status</h6>
                    
                                  {item.isPending ? <b>Pending...<span>&#8987;</span> </b> : <p className='text-white'>Approved <span>&#9989;</span></p>}
                                </div>
                              </div>

                            </>
                          )
                        })
                      }
                </div>
            </div>
        </div>
    </div>
   </Layout>
   </>
  )
}

export default ProfileDashboard